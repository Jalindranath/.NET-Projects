﻿//function RemoveAdmin(name) { 
//    console.log(name);  
 //   document.getElementById("text").innerText = `That will make ${name} unauthorized to access any data..\n  Are you sure to remove ${name} from admin?`;
    //document.getElementById("removeBtn").classList.remove("btn btn-success");
   // document.getElementById("removeBtn").href = `/account/confirmRemoveAdmin?userName=${name}`;
//}
