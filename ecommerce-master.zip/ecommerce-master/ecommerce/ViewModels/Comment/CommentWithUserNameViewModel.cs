﻿namespace ecommerce.ViewModels.Comments
{
    public class CommentWithUserNameViewModel
    {
        public int Id { get; set; }

        public string text { get; set; }

        public string userName { get; set; }
    }
}
