﻿namespace ecommerce.ViewModels
{
    public class forceEmailConfirmationMailAdditionalParamsViewModel
    {

    }
}
