﻿using ecommerce.Models;
using ecommerce.Repository;

namespace ecommerce.Services
{
    public interface IShipmentService : IRepository<Shipment>
    {

    }
}
