select * from [Order]

select * from OrderItem