﻿using ecommerce.Models;

namespace ecommerce.Repository
{
    public interface ICartRepository : IRepository<Cart>
    {

    }
}
