﻿using ecommerce.Models;

namespace ecommerce.Repository
{
    public interface IShipmentRepository : IRepository<Shipment>
    {
      //  public List<Product> GetShipmentDetails(int id);
    }
}
