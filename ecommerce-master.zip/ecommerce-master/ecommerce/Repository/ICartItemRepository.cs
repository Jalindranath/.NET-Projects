﻿using ecommerce.Models;

namespace ecommerce.Repository
{
    public interface ICartItemRepository : IRepository<CartItem>
    {

    }
}
