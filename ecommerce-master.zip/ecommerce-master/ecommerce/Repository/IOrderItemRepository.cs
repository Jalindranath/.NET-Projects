﻿using ecommerce.Models;

namespace ecommerce.Repository
{
    public interface IOrderItemRepository : IRepository<OrderItem>
    {
    }
}
